-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: smart_grovesdrs
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tree`
--

DROP TABLE IF EXISTS `tree`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tree` (
  `tree_id` int NOT NULL,
  `plant_date` date DEFAULT '2000-01-01',
  `height` decimal(10,2) DEFAULT NULL,
  `trunk_diameter` decimal(10,2) DEFAULT NULL,
  `canopy_radius` decimal(10,2) DEFAULT NULL,
  `root_depth` decimal(10,2) DEFAULT NULL,
  `species` varchar(255) DEFAULT NULL,
  `scientific_name` varchar(255) DEFAULT NULL,
  `is_deciduous` tinyint(1) DEFAULT NULL,
  `plant_year` int DEFAULT NULL,
  `max_age` int DEFAULT NULL,
  `health_status` decimal(10,2) DEFAULT NULL,
  `is_flowering` tinyint(1) DEFAULT NULL,
  `foliage_density` decimal(10,2) DEFAULT NULL,
  `water_level` decimal(10,2) DEFAULT NULL,
  `Fertile_age` int DEFAULT '5',
  `Low_yield_threshold` int DEFAULT NULL,
  `is_harvestable` tinyint(1) DEFAULT NULL,
  `species_id` int DEFAULT NULL,
  PRIMARY KEY (`tree_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tree`
--

LOCK TABLES `tree` WRITE;
/*!40000 ALTER TABLE `tree` DISABLE KEYS */;
INSERT INTO `tree` VALUES (1,'2000-01-01',5.00,0.50,2.00,1.50,'Olive Tree','Olea europaea',0,2000,100,1.00,1,0.80,0.70,5,50,1,1),(2,'2000-01-01',4.50,0.40,1.80,1.20,'Olive Tree','Olea europaea',0,2000,100,1.00,1,0.70,0.60,5,50,1,1);
/*!40000 ALTER TABLE `tree` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-07 17:20:24
