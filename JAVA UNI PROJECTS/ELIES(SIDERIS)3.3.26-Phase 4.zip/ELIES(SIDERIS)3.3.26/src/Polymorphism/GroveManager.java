package Polymorphism; //σε ποιο package ανηκει η κλαση

import java.util.ArrayList; //array list για να αποθηκευσουμε πολλα δεντρα
public class GroveManager {  //κλαση που διαχειριζεται ολο το grove
    private ArrayList<OliveTree> trees = new ArrayList<>(); // φτιαχνουμε μια λιστα που να αποθηκευει OliveTree

    public void addTree(OliveTree tree) { //μεθοδος για να προσθεσουμε δεντρο στην λιστα
        trees.add(tree); //προσθετουμε δεντρο στην λιστα
    }
    public void harvestAllTrees() { //μεθοδος που κανει harvest ολα τα δεντρα
        for (OliveTree tree : trees) { //loop που περναει απο καθε δεντρο μεσα στην λιστα
            try { //ελεγχος για errors
                double product = tree.harvestFruit();//καλουμε τη μεθοδο HarvestFruit απο καθε δεντρο και περνουμε την παραγωγη λαδιου
                if (product < tree.lowYieldThreshold) { //αν η παραγωγη ειναι μικροτερη απο 50
                    throw new LowYieldException("Low production from tree!"); //τοτε δημιουργουμε και πεταμε custom exceptions
                }
                System.out.println("Oil produced: " + product + " liters"); //αν ολα ειναι σωστα εμφανιζουμε αποτελεσμα
            } catch (LowYieldException e) { //πιανουμε το exception που πεταμε
                System.out.println("Warning: " + e.getMessage()); //εμφανιζουμε μυνημα σφαλματος στον χρηστη
            }
        }
    }
}
