package Polymorphism;//δηλωνω σε ποιο package ανηκει η κλαση
import java.sql.*;//εισαγω βιβλιοθηκη για βαση δεδομενων
import com.mysql.cj.jdbc.Driver;//driver για sql
public class DBConnection {
   private static String URL = "jdbc:mysql://localhost:3306/smart_groveSDRS"; // διευθυνση βασης
   private static String USER = "root"; //username
   private static String PASSWORD = "1234"; //password

   public static Connection getConnection() {
      try {
         Class.forName("com.mysql.cj.jdbc.Driver");//φωρτωνω driver
         Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);// δημιουργω συνδεση
         System.out.println("Connection successful!"); // σε περιπτωση που πετυχει η συνδεση εμφανιζω μυνημα
         return conn;//επιστρεφω συνδεση

      } catch (Exception e) {
         System.out.println("Connection failed.");// σε περιπτωση που αποτυχει η συνδεση εμφανιζω μυνημα
         return null;
      }
   }
}