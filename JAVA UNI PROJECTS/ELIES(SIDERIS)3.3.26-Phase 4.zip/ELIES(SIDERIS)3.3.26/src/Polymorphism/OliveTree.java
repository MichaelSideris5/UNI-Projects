package Polymorphism; //δηλωνω σε ποιο package ανηκει η κλαση

import java.time.LocalDate; //εισαγω την τωρινη ημερομηνια

public class OliveTree extends Tree implements Harvestable {
    //χρησιμοποιω inheritance με το extends Tree για να κληρονομησει τα properties
    //χρησιμοποιω το polymorphism με το implements Harvestable για να υλοποιησει το interface
    private double oilContent;   // ποσοστό λαδιού
    private double yieldAmount;// κιλά ελιάς
    private String oliveType;//τυπος ελιας
    private boolean isGnarled;// αν ειναι στριφογυριστος ο κορμος
    private boolean isAlternateBearing; //αν ειναι χρονια με μεγαλη παραγωγη
    public OliveTree(double height, double trunkDiameter, double canopyRadius, double rootDepth,
                     int plantYear, int maxAge,
                     double healthStatus, boolean isFlowering,
                     double foliageDensity, double waterLevel,
                     String oliveType, double yieldAmount,
                     double oilContent, boolean isGnarled,
                     boolean isAlternateBearing,int fertileAge,int lowYieldThreshold,boolean isHarvestable) { //δημιουργω αντικειμενο OliveTree
        super(height,
                trunkDiameter,
                canopyRadius, rootDepth,
                "Olive Tree",
                "Olea europaea",
                false,
                plantYear,
                maxAge,
                healthStatus,
                isFlowering,
                foliageDensity,
                waterLevel,
                fertileAge,
                lowYieldThreshold,
                isHarvestable); //καλω τον constructor της Tree
        this.oilContent = 25.0; //το ποσοστο λαδιου(The oilContent in each olive should be 25%)
        this.yieldAmount = 300; //κιλα λαδιου(The kgr of olives collected should be 300)
        this.oliveType = oliveType;//τυπος ελιας
    }
    @Override
    public double collectYield() { // μεθοδος απο interface
        return yieldAmount; //παραγωγη ελιας
    }
    @Override
    public double harvestFruit() {
        LocalDate date = LocalDate.now(); //παιρνω τωρινη ημερομηνιας
        int year = date.getYear(); // παιρνω ετος
        int month = date.getMonthValue(); //παιρνω μηνα
        int treeAge = year - 2000; //υπολογιζω την ηλικια(The plantYear should be set to 2000)
        if (treeAge > fertileAge && //(A tree should produce oil only if treeAge>fertileAge)
                (month == 11 || month == 12 || month == 1 ||
                        month == 2 || month == 3)) { //ελεγχω ηλικια και  συγκεκριμενους μηνες (The production could take place only during November, December, January, February or March)
            double product = yieldAmount * oilContent; //υπολογιζω λαδι (It should return a double named product)
            return product;//αποτελεσμα
        }
        return 0;//αποτελεσμα αν δεν εκπληρωνονται οι συνθηκες
    }
    public String getOliveType() { // getter για τον τυπο της ελιας

        return oliveType;//επιστρεφω το oliveType του δεντρο
    }
    public double getYieldAmount() { // getter για την ποσοτητα παραγωγης (κιλα ελιας)
        return yieldAmount;// επιστρεφω ποσα κιλα ελιας παραγονται
    }

    public double getOilContent() { // getter για το ποσοστο λαδιου
        return oilContent;// επιστρεφω το ποσοστο λαδιου της ελιας
    }

    public boolean getIsGnarled() {//getter για αν ο κορμος ειναι στριφογυριστος
        return isGnarled;//επιστρεφει true or false
    }

    public boolean getIsAlternateBearing() {//getter για αν ειναι χρονια με μεγαλη παραγωγη
        return isAlternateBearing;//επιστρεφει true or false
    }
}