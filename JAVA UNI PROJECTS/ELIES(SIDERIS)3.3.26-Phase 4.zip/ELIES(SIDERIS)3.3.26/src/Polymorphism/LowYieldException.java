package Polymorphism;// σε ποιο pagkage ειναι
public class LowYieldException extends Exception { //δημιουργουμε custom exception και το extends exception σημαινει οτι ειναι τυπος error
    public LowYieldException(String message) { //constructor που δεχεται μηνυμα
        super(message); //στελνουμε το μυνημα στην parent class
    }
}
