package Polymorphism;//δηλωνω σε ποιο package ανηκει η κλαση
import java.sql.*;//εισαγω βιβλιοθηκη για βαση δεδομενων
import com.mysql.cj.jdbc.Driver; //driver για sql
public class DB {
    public void insertTree(OliveTree tree,int id) { //μεθοδος για εισαγωγη δεδομενων στη βαση
        try {
            Connection conn = DBConnection.getConnection();//δημιουργω συνδεση με την βαση
            Statement stmt = conn.createStatement();//κανω statement για να γινουν οι εντολες τις sql
            String treeQuery =
                    "INSERT INTO tree VALUES (" + id + ", "  // id του tree
                            +"'2000-01-01', " + // default plant date
                            tree.height + ", " + // υψος δεντρου
                            tree.trunkDiameter + ", " + // διαμετρος κορμου
                            tree.canopyRadius + ", " + // απλωμα κλαδιων
                            tree.rootDepth + ", " + // βαθος ριζας
                            "'" + tree.species + "', " + // ειδος δεντρου
                            "'" + tree.scientificName + "', " + // επιστημονικο ονομα
                            "false, " + // αν ειναι deciduous
                            tree.plantYear + ", " + // ετος φυτευσης
                            tree.maxAge + ", " + // μεγιστη ηλικια
                            tree.healthStatus + ", " + // υγεια δεντρου
                            tree.isFlowering + ", " + // αν ανθιζει
                            tree.foliageDensity + ", " + // πυκνοτητα φυλλων
                            tree.waterLevel + ", " + // επιπεδο νερου
                            tree.fertileAge + ", " + // ηλικια καρποφοριας
                            tree.lowYieldThreshold + ", " + // οριο χαμηλης παραγωγης
                            tree.isHarvestable + ", " + // αν μπορει να γινει harvest
                            "1)"; // species id
            stmt.executeUpdate(treeQuery);//κανω εισαγωγη στον πινακα tree
            String oliveQuery =
                    "INSERT INTO olive_tree VALUES (" +
                            id +", " + // ιδιο id με το tree
                            "'" + tree.getOliveType() + "', " + // ποικιλια ελιας
                            tree.getYieldAmount() + ", " + // κιλα ελιας
                            tree.getOilContent() + ", " + // ποσοστο λαδιου
                            tree.getIsGnarled() + ", " + // αν ο κορμος ειναι στριφος
                            tree.getIsAlternateBearing() + ", " + // αν εχει alternate bearing
                            "'Mediterranean')"; // olive tree type
            stmt.executeUpdate(oliveQuery); // κανω εισαγωγη στον πινακα olivetree
            System.out.println("Data inserted!");//σε περιπτωση που δουλεψει εμφανιζω μυνημα
            conn.close();//κλεινω την συνδεση

        } catch (Exception e) {
            System.out.println(e);//αν υπαρχει σφαλμα εμφανιζω μυνημα και τι σφαλμα υπαρχει
        }
    }
}