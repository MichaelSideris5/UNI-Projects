package Polymorphism; //δηλωνω σε ποιο package ανηκει η κλαση

public interface Harvestable { //δημιουργω κανονα interface για να χρησιμοποιηση οποιαδηποτε κλαση

    double collectYield(); //μεθοδος χωρις σωμα που θα υλοποιηθει αλλου

    double harvestFruit(); //μεθοδος χωρις σωμα που θα υλοποιηθει αλλου

}
