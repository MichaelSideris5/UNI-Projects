package Polymorphism; //δηλωνω σε ποιο package ανηκει η κλαση

import java.time.LocalDate; //εισαγω την τωρινη ημερομηνια

public class OliveTree extends Tree implements Harvestable {
    //χρησιμοποιω inheritance με το extends Tree για να κληρονομησει τα properties
    //χρησιμοποιω το polymorphism με το implements Harvestable για να υλοποιησει το interface
    private double oilContent;   // ποσοστό λαδιού
    private double yieldAmount;  // κιλά ελιάς
    public OliveTree(int plantYear, double height, double trunkDiameter, double healthStatus) { //δημιουργω αντικειμενο OliveTree
        super(height, trunkDiameter, 1.0, 1.0,
                "Olive Tree", "Olea europaea", false,
                plantYear, 100,
                healthStatus, true,
                1.0, 1.0); //καλω τον constructor της Tree
        this.oilContent = 0.25; //το ποσοστο λαδιου(The oilContent in each olive should be 25%)
        this.yieldAmount = 300; //κιλα λαδιου(The kgr of olives collected should be 300)
    }
    @Override
    public double collectYield() { // μεθοδος απο interface
        return yieldAmount; //παραγωγη ελιας
    }
    @Override
    public double harvestFruit() {
        LocalDate date = LocalDate.now(); //παιρνω τωρινη ημερομηνιας
        int year = date.getYear(); // παιρνω ετος
        int month = date.getMonthValue(); //παιρνω μηνα
        int treeAge = year - 2000; //υπολογιζω την ηλικια(The plantYear should be set to 2000)
        if (treeAge > 5 && //(A tree should produce oil only if treeAge>5)
                (month == 11 || month == 12 || month == 1 ||
                        month == 2 || month == 3)) { //ελεγχω ηλικια και  συγκεκριμενους μηνες (The production could take place only during November, December, January, February or March)
            double product = yieldAmount * oilContent; //υπολογιζω λαδι (It should return a double named product)
            return product;//αποτελεσμα
        }
        return 0;//αποτελεσμα αν δεν εκπληρωνονται οι συνθηκες
    }
}