package Polymorphism;//δηλωνω σε ποιο package ανηκει η κλαση

public class OliveGrove {
    public static void main(String[] args) {
        OliveTree tree = new OliveTree(2000, 4.0, 0.5, 0.9);
        //δημιουργω το αντικειμενο
        double oil = tree.harvestFruit();//καλω μεθοδο
        System.out.println("Oil produced: " + oil + " liters");//εκτυπωνω το αποτελεσμα
    }
}
