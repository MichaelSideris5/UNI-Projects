package Inheritance;

public class OliveTree extends Tree { // η κλαση Olive Tree κληρωνομει τις τιμες απο την superclass Tree μεσω inheritance
    private String oliveType; // private γιατι ειναι ειδικα για ελια και ειναι για την ποικιλια της ελιας(πχ.Kalamata,Koroneiki)
    private double yieldAmount; // ποσο ελια παραγει
    private double oilContent; // πσοστο λαδιου
    private boolean isGnarled; // αν ειναι στριφογυριστος ο κορμος
    private boolean isAlternateBearing; //αν ειναι χρονια με μεγαλη παραγωγη
    public OliveTree(double height, double trunkDiameter, double canopyRadius, double rootDepth,
                     int plantYear, int maxAge,
                     double healthStatus, boolean isFlowering,
                     double foliageDensity, double waterLevel,
                     String oliveType, double yieldAmount,
                     double oilContent, boolean isGnarled,
                     boolean isAlternateBearing) {
        super(height, trunkDiameter, canopyRadius, rootDepth, "Olive Tree", "Olea europaea", false,
                plantYear, maxAge, healthStatus, isFlowering, foliageDensity, waterLevel);
        this.oliveType = oliveType; // με το this αποθηκευουμε τις τιμες της ελιας( το ιδιο κανουμε και στα αλλα attributes)
        this.yieldAmount = yieldAmount;
        this.oilContent = oilContent;
        this.isGnarled = isGnarled;
        this.isAlternateBearing = isAlternateBearing;
    } // καλουμε το constructor της κλασης Tree με το super
    public double harvestOlives() {
        double harvest;
        if (isAlternateBearing) { // αν η παραγωγη ειναι βαρια τοτε περισσοτερες ελιες
            harvest = yieldAmount * 1.5; // πολλαπλασιαζουμε την παραγωγη της ελιας με 1.5 αν η παρωγη ειναι βαρια
        } else {
            harvest = yieldAmount * 0.5;  //πολλαπλασιαζουμε την παραγωγη της ελιας με 0.5 αν η παρωγη ειναι ελαφρια
        }

        isAlternateBearing = !isAlternateBearing; //αλλαζουμε την κατασταση για την επομενη σοδια

        return harvest;
    }
    public double calculateOilYield(double harvestedOlives) {
        return harvestedOlives * oilContent; // υπολιγιζουμε κιλα ελιας με το ποσοστο του λαδιου
    }
}
