package Polymorphism; //δηλωνω που ανηκει η κλαση
public class OliveGrove {// main class απο οπου ξεκιναει το προγραμμα
    public static void main(String[] args) { // η main method ειναι το σημειο εκκινησης του προγραμματος
        GroveManager manager = new GroveManager();// δημιουργουμε ενα αντικειμενο GroveManager που θα διαχειριζεται τα δεντρα
        OliveTree tree1 = new OliveTree(
                5.0, 0.5, 2.0, 1.5,
                2000, 100,
                1.0, true,
                0.8, 0.7,
                "Koroneiki", 300,
                0.25, true,
                true);// τιμες πρωτου δεντρου
        OliveTree tree2 = new OliveTree(
                4.5, 0.4, 1.8, 1.2,
                2000, 100,
                1.0, true,
                0.7, 0.6,
                "Kalamata", 100,
                0.25, false,
                false);//τιμες δευτερου δεντρου με μικροτερη παραγωγη
        manager.addTree(tree1);//εβαλα το πρωτο δεντρο στην λιστα
        manager.addTree(tree2);//εβαλα και το δευτερο δεντρο στη λιστα
        manager.harvestAllTrees();//καλω την μεθοδο harvest
    }
}