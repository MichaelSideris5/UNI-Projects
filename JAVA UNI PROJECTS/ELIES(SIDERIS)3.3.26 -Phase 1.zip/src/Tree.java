import java.time.LocalDate;

public class Tree {
    protected double height; //το υψος του δεντρου
    protected double trunkDiameter; // η διαμετρος του κορμου
    protected double canopyRadius; // ποσο απλονονται τα κλαδια
    protected double rootDepth; // το βαθος της ριζας
    protected String species; // το ειδος του δεντρου ( πχ.White Oak)
    protected String scientificName; // το επιστημονικο ονομα του (πχ."Quercus alba")
    protected boolean isDeciduous; // αν εχει φυλλα
    protected int plantYear; // ποτε εμφυτευτηκε
    protected int maxAge; // η ηλικια του
    protected double healthStatus; // η υγεια του
    protected boolean isFlowering; // αν ανθιζει
    protected double foliageDensity; // η πυκνοτητα στα φυλλα του
    protected double waterLevel; // ποσο νερο θελει
    public Tree(double height, double trunkDiameter, double canopyRadius, double rootDepth,
                String species, String scientificName, boolean isDeciduous,
                int plantYear, int maxAge,
                double healthStatus, boolean isFlowering,
                double foliageDensity, double waterLevel) // constructor που δημιουργει το αντικειμενο Tree
    {

        this.height = height; // this για να να δειξουμε το υψως αυτου του αντικειμενου(το ιδιο κανουμε και στα αλλα attributes)
        this.trunkDiameter = trunkDiameter;
        this.canopyRadius = canopyRadius;
        this.rootDepth = rootDepth;
        this.species = species;
        this.scientificName = scientificName;
        this.isDeciduous = isDeciduous;
        this.plantYear = plantYear;
        this.maxAge = maxAge;
        this.healthStatus = healthStatus;
        this.isFlowering = isFlowering;
        this.foliageDensity = foliageDensity;
        this.waterLevel = waterLevel;
    }
    public String produceFruit() // μεθοδος που επιστρεφει string
    {
        LocalDate date = LocalDate.now();
        int currentYear = date.getYear();
        int currentMonth = date.getMonthValue();
        int age = currentYear - plantYear; // υπολογιζουμε την ηλικια

        if (age > 5  && currentMonth == 11 && healthStatus > 0.5 && isFlowering) {
            return "Fruit produced.";
        }

        return "No fruit."; // ελεγχουμε αν παραγει καρπο
    }
    public double harvestWood() //επιστρεφει την ποσοτητα του ξυλου
    {
        double wood = trunkDiameter * height; //υπολογιζουμε ποσο ξυλο θα δωσει

        healthStatus = 0; // το δεντρο πεθαινει αφου το κοψουμε

        return wood;
    }
}


