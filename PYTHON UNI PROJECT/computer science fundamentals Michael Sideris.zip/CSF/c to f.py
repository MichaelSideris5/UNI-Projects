def get_temperatures():
    temps =[]
    times = int(input("How many temperatures? "))
    for i in range(times):
        temp = float(input(f"Insert temperature {i+1} in C: "))
        temps.append(temp)
    return temps
def c_to_f(c):
    """F = 1.8*X + 32"""
    return (c*9/5) + 32
def convert_all(temps):
    f_temps=[]
    for c in temps:
        f_temps.append(c_to_f(c))
    return f_temps
def display_results(temps, f_temps):
    print("\nCelsius | Fahrenheit")
    print("----------------")
    for c, f in zip(temps, f_temps):
        print(f"{c:10} | {f:.2f}")
    print ("----------------")
def main():
    temps = get_temperatures()
    f_temps = convert_all(temps)
    display_results(temps, f_temps)
main()
