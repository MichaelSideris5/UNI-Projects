import random
from datetime import datetime

choices = ["rock", "paper", "scissors"]

print(" Rock – Paper – Scissors ")

username = input("Enter username: ").strip()
while username == "":
    username = input("Username cannot be empty. Enter username: ").strip()

user_score = 0
computer_score = 0

while user_score < 10 and computer_score < 10:
    print(f"\nScore → {username}: {user_score} | Computer: {computer_score}")
    user_choice = input("Choose rock, paper, or scissors: ").lower().strip()

    if user_choice not in choices:
        print("Invalid choice. Try again.")
        continue

    computer_choice = random.choice(choices)

    print(f"You chose: {user_choice}")
    print(f"Computer chose: {computer_choice}")


    if user_choice == computer_choice:
        print("It's a tie!")
    elif (
        (user_choice == "rock" and computer_choice == "scissors") or
        (user_choice == "scissors" and computer_choice == "paper") or
        (user_choice == "paper" and computer_choice == "rock")
    ):
        print("You win this round!")
        user_score += 1
    else:
        print("Computer wins this round!")
        computer_score += 1


print("\n Game Over ")
print(f"Final score → {username}: {user_score} | Computer: {computer_score}")


with open("scores.txt", "a") as file:
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    file.write(f"{username},{timestamp},{user_score},{computer_score}\n")

print("Score saved to scores.txt")
