file = open("scores.txt", "r")
lines = file.readlines()
file.close()

usernames = []
user_scores = []
computer_scores = []


for line in lines:
    data = line.strip().split(",")

    if len(data) == 4:
        usernames.append(data[0])
        user_scores.append(int(data[2]))
        computer_scores.append(int(data[3]))


n = len(user_scores)

for i in range(n):
    for j in range(0, n - i - 1):
        if user_scores[j] < user_scores[j + 1]:
            
            temp = user_scores[j]
            user_scores[j] = user_scores[j + 1]
            user_scores[j + 1] = temp

            
            temp = usernames[j]
            usernames[j] = usernames[j + 1]
            usernames[j + 1] = temp

            
            temp = computer_scores[j]
            computer_scores[j] = computer_scores[j + 1]
            computer_scores[j + 1] = temp

print(" TOP 5 PLAYERS ")

limit = 5
if n < 5:
    limit = n

for i in range(limit):
    print(
        str(i + 1) + ".",
        usernames[i],
        "- User:", user_scores[i],
        "Computer:", computer_scores[i]
    )
