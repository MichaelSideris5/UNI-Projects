import csv
import os
import random
from datetime import datetime

USERS_FILE = "users.csv"
QUESTIONS_FILE = "questions.csv"
SCORES_FILE = "quiz_scores.csv"
NUM_QUESTIONS = 5


def ensure_files():
    
    if not os.path.exists(USERS_FILE):
        with open(USERS_FILE, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["username", "password"])

    
    if not os.path.exists(SCORES_FILE):
        with open(SCORES_FILE, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["username", "datetime", "score", "out_of"])


def load_users():
    users = {}
    with open(USERS_FILE, "r", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            users[row["username"]] = row["password"]
    return users


def save_user(username, password):
    with open(USERS_FILE, "a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([username, password])


def register(users):
    print("\n=== Register ===")
    while True:
        username = input("Choose username: ").strip()
        if not username:
            print("Username cannot be empty.")
            continue
        if username in users:
            print("Username already exists.")
            continue

        password = input("Choose password: ").strip()
        confirm = input("Confirm password: ").strip()
        if password != confirm:
            print("Passwords do not match.")
            continue

        save_user(username, password)
        print("Registered! You are now logged in.")
        return username


def login(users):
    print("\n=== Login ===")
    username = input("Username: ").strip()
    password = input("Password: ").strip()

    if username not in users:
        print("No such user.")
        return None

    if users[username] != password:
        print("Wrong password.")
        return None

    print(f"Welcome, {username}!")
    return username


def load_questions():
    questions = []
    with open(QUESTIONS_FILE, "r", newline="", encoding="utf-8") as f:
        reader = csv.reader(f)
        for row in reader:
            if len(row) == 5:  
                questions.append(row)
    return questions


def ask_question(row):
    question, correct, w1, w2, w3 = [x.strip() for x in row]

    answers = [correct, w1, w2, w3]
    random.shuffle(answers)

    print("\n" + question)
    for i, ans in enumerate(answers, start=1):
        print(f"{i}) {ans}")

    choice = input("Answer (1-4): ").strip()
    if choice not in ["1", "2", "3", "4"]:
        print("Invalid. Counting as wrong.")
        return False

    chosen_answer = answers[int(choice) - 1]
    if chosen_answer == correct:
        print("Correct!")
        return True
    else:
        print("Wrong! Correct answer:", correct)
        return False


def save_score(username, score, total):
    dt = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(SCORES_FILE, "a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([username, dt, score, total])


def run_quiz(username):
    questions = load_questions()

    if len(questions) < NUM_QUESTIONS:
        print(f"Not enough questions (need at least {NUM_QUESTIONS}).")
        return

    chosen = random.sample(questions, NUM_QUESTIONS)

    score = 0
    for q in chosen:
        if ask_question(q):
            score += 1

    print(f"\n=== Finished ===")
    print(f"Score: {score}/{NUM_QUESTIONS}")
    save_score(username, score, NUM_QUESTIONS)


def main():
    ensure_files()

    if not os.path.exists(QUESTIONS_FILE):
        print("Missing questions.csv file. Create it first.")
        return

    username = None
    while username is None:
        users = load_users()
        print("\n=== Quiz App ===")
        print("1) Login")
        print("2) Register")
        print("3) Exit")
        option = input("Choose: ").strip()

        if option == "1":
            username = login(users)
        elif option == "2":
            username = register(users)
        elif option == "3":
            print("Goodbye!")
            return
        else:
            print("Invalid option.")

    while True:
        run_quiz(username)
        again = input("\nPlay again? (y/n): ").strip().lower()
        if again != "y":
            print("Bye")
            break


if __name__ == "__main__":
    main()
