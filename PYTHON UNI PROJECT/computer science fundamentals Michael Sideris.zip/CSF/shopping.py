def get_prices():
    prices = []
    num_items = int(input("How many items did you buy? "))

    for i in range(num_items):
        price = float(input(f"Enter price of item {i + 1}: "))
        prices.append(price)

    return prices


def calculate_total(prices):
    return sum(prices)


def add_tax(total):
    tax_rate = 0.10
    return total + (total * tax_rate)


def display_bill(total, total_with_tax):
    print("\n🧾 Final Bill")
    print(f"Total before tax: €{total:.2f}")
    print(f"Total after 10% tax: €{total_with_tax:.2f}")


prices = get_prices()
total = calculate_total(prices)
total_with_tax = add_tax(total)
display_bill(total, total_with_tax)
